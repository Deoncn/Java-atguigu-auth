// 引用调用方法在 js 文件
var m = require('./01.js')

// 调用方法

var v1 = m.sum(1,2)
console.log(v1)

var v2 = m.sub(3,1)
console.log(v2)
