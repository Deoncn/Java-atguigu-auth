'use strict';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.list = list;
exports.add = add;
function list() {
    console.log('list......');
}

function add() {
    console.log('add......');
}