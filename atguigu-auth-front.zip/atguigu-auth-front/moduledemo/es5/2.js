'use strict';

var _ = require('./1.js');

// 调用

(0, _.list)(); // 引入

(0, _.add)();