// 引入
import m from './01.js'

//调用

m.getlist()
m.save()